import {TableCell, TextField} from "@mui/material";
import React from "react";

export default function CustomTableCell({onChange, name, value, isEdit}) {

    return isEdit ? (
        <TableCell>
            <TextField
                id="outlined-basic"
                name={name}
                label={name}
                variant="outlined"
                sx={{width: "100%"}}
                value={value}
                onChange={onChange}
            />
        </TableCell>
    ) : (
        <TableCell>{value}</TableCell>
    );
}
