import React, {useEffect, useRef} from 'react'
import {useState} from 'react'
import {Button, ButtonGroup, TableCell, TableRow, TextField} from "@mui/material";
import CheckIcon from "@mui/icons-material/Check";
import ClearIcon from "@mui/icons-material/Clear";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import CustomTableCell from "./CustomTableCell";

export default function RowOther({item, onSubmit, isOwner}) {
    const [isEdit, setIsEdit] = useState(false);
    const [row, setRow] = useState(item);

    useEffect(() => {
            setRow(item);
        }, [item]
    )

    const handleChange = (evt) => {
        const {name, value} = evt.target;

        setRow(prev => ({
            ...prev,
            [name]: value
        }))
    };

    const validerEdit = () => {
        setIsEdit(false);
        onSubmit(row);
    }

    const annulerEdit = () => {
        setRow(item);
        setIsEdit(false);
    }

    const toggleEdit = () => {
        setIsEdit(!isEdit);
    }

    return (
        <TableRow>
            <CustomTableCell onChange={handleChange} name="name" value={row.name} isEdit={isOwner && isEdit}/>
            <CustomTableCell onChange={handleChange} name="comment" value={row.comment} isEdit={isOwner && isEdit}/>
            {!isOwner && <CustomTableCell onChange={handleChange} name="done" value={row.done} isEdit={isEdit}/>}
            {!isOwner && <CustomTableCell onChange={handleChange} name="doneComment" value={row.doneComment} isEdit={isEdit}/>}

            {isEdit ? (
                <TableCell style={{width: 100}}>
                    <ButtonGroup>
                        <Button variant="contained" color="success" onClick={validerEdit}>
                            <CheckIcon/>
                        </Button>
                        <Button variant="contained" color="error" onClick={annulerEdit}>
                            <ClearIcon/>
                        </Button>
                    </ButtonGroup>
                </TableCell>
            ) : (
                <TableCell>
                    <ButtonGroup variant="contained" aria-label="Basic button group">
                        <Button variant="contained" onClick={toggleEdit}><EditIcon/></Button>
                        {isOwner && (<Button variant="contained" color="error"
                                             onClick={() => onDelete(row.id)}><DeleteIcon/></Button>)}
                    </ButtonGroup>
                </TableCell>
            )}
        </TableRow>
    );
}
