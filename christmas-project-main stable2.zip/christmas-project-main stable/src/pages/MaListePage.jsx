import React, {useEffect, useState} from 'react'
import {addItem, deleteItem, updateItems} from '../api'
import {Box, Button, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TextField} from "@mui/material";
import Paper from "@mui/material/Paper";
import RowOther from "../components/RowOther";

export default function OtherListePageOld({user, currentList, updateCB, isListOwner}) {
    const [name, setName] = useState('')
    const [comment, setComment] = useState('')
    const [error, setError] = useState(null)
    const [currentItems, setCurrentItems] = useState();

    useEffect(() => {
        setCurrentItems(currentList)// todo voir perf
    }, [currentList])

    // Maj state parent en CB
    useEffect(() => {
        //updateCB(currentItems);
    }, [currentItems]);

    async function handleAdd(e) {
        e.preventDefault()
        if (!name.trim()) return
        try {
            const newTodo = await addItem(user.id, name.trim(), comment)
            setCurrentItems((t) => [...t, newTodo]);
            setName('');
            setComment('');
        } catch (err) {
            console.log(err.message)
        }
    }

    async function handleDelete(id, name, comment) {
        try {
            await deleteItem(user.id, id);
            setCurrentItems((item) => item.filter((x) => x.id !== id))
        } catch (err) {
            console.error(err);
        }
    }

    async function handleSubmit(id, name, comment) {
        try {
            const res = await updateItems(user, id, name, comment);
            setCurrentItems(currentItems.map((item) => (item.id === res.id ? {
                ...item,
                name: res.name,
                comment: res.comment
            } : item)));
        } catch (err) {
            console.error(err);
        }
    }

    return (
        <>
            {isListOwner && (
                <Box sx={{
                    borderBottom: 1,
                    borderColor: 'divider',
                    marginTop: 1,
                    paddingBottom: 3,
                    marginBottom: 3,
                    justifyContent: 'center',
                    alignItems: 'center',
                    display: 'flex',
                }}>
                    <p>Ajouter un élément </p>
                    <TextField size="small" id="outlined-basic" label="nom" variant="outlined" value={name}
                               onChange={(e) => setName(e.target.value)}/>
                    <TextField size="small" id="outlined-basic" label="commentaire" variant="outlined"
                               value={comment}
                               onChange={(e) => setComment(e.target.value)}/>
                    <Button type="submit" variant="contained" onClick={handleAdd}>Ajouter</Button>
                </Box>
            )}

            <TableContainer component={Paper}>
                <Table sx={{minWidth: 650, tableLayout: "fixed"}} aria-label="simple table">
                    <TableHead sx={{'& .MuiTableCell-root': {fontWeight: 'bold'}}}>
                        <TableRow>
                            <TableCell align="left">Nom</TableCell>
                            <TableCell align="left">Commentaire</TableCell>
                            {!isListOwner && <TableCell align="left">Fait</TableCell>}
                            {!isListOwner && <TableCell align="left">Commentaire</TableCell>}
                            <TableCell align="left">Actions</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {currentItems && currentItems.map((t) => (
                            <RowOther key={t.id} item={t} onSubmit={handleSubmit} onDelete={handleDelete} isOwner={isListOwner}/>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
        </>
    )
}
