import React, { useRef, useState, useEffect } from 'react';
import ScramblerUtils from "../utils/ScramblerUtil";

export default function Scrambler() {
    const [text, setText] = useState('Liste de noel');
    const scramblerRef = useRef(new ScramblerUtils());

    useEffect(() => {
        // call scramble function with the text to be scrambled and handler.
        const inverval = setInterval(()=> {
            scramblerRef.current.scramble(()=>generateTitle(text), setText);
        }, 3000);
    }, []);

    function generateTitle() {
        const words = [
            "Super", "Digital", "ensoleillé", "technologique", "Rock",
            "Alimentaire", "Solutions", "Technologie", "Avenir", "Impact",
            "Convoyeur", "Optimisation", "Surprise", "Mega", "Synergie"
        ];

        const numberOfWords = Math.floor(Math.random() * 3) + 3; // 3, 4 ou 5 mots
        const selected = [];

        for (let i = 0; i < numberOfWords; i++) {
            const word = words[Math.floor(Math.random() * words.length)];
            selected.push(word);
        }

        return selected.join(" ");
    }

    return <h1>{text}</h1>

}
