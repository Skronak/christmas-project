export const allUsers = [
    {id: 4, name: 'Aurelie'},
    {id: 6, name: 'Arthur'},
    {id: 5, name: 'Fred'},
    {id: 7, name: 'Gabriel'},
    {id: 3, name: 'Gilles'},
    {id: 1, name: 'Guillaume'},
    {id: 8, name: 'Julie'},
    {id: 2, name: 'Mireille'},
    {id: 8, name: 'Maman Fred'}];

export const itemMock = [
    {id: 1, userId: 1, name: "Chausson", comment: "cest fait", done: 0, doneBy: 0, doneComment: ""},
    {id: 2, userId: 1, name: "patin a glace", comment: "", done: 0, doneBy: 0, doneComment: ""},
    {id: 3, userId: 2, name: "Voiture electrique", comment: "", done: 0, doneBy: 0, doneComment: ""},
    {id: 4, userId: 2, name: "Café", comment: "", done: 0, doneBy: 0, doneComment: ""},
    {id: 5, userId: 3, name: "Arbre de transmission pour la renault", comment: "", done: 0, doneBy: 0, doneComment: ""}
]
export const drawerWidth = 240;
